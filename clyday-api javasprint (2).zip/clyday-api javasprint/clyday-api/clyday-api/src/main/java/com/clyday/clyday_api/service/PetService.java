package com.clyday.clyday_api.service;


import com.clyday.clyday_api.dto.PetDTO;
import com.clyday.clyday_api.entity.Pet;
import com.clyday.clyday_api.entity.Tutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.clyday.clyday_api.repository.PetRepository;
import com.clyday.clyday_api.repository.TutorRepository;

@Service
public class PetService {

    @Autowired
    private PetRepository petRepository;

    @Autowired
    private TutorRepository tutorRepository;

    public Pet salvar(PetDTO dto) {

        Tutor tutor = tutorRepository.findById(dto.getTutorId())
                .orElseThrow(() -> new RuntimeException("Tutor não encontrado"));

        Pet pet = new Pet();

        pet.setNome(dto.getNome());
        pet.setEspecie(dto.getEspecie());
        pet.setTutor(tutor);

        return petRepository.save(pet);
    }

    public Page<Pet> listar(Pageable pageable) {
        return petRepository.findAll(pageable);
    }

    public Pet buscarPorId(Long id) {
        return petRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pet não encontrado"));
    }

    public void deletar(Long id) {
        petRepository.deleteById(id);
    }
}
