package com.clyday.clyday_api.service;

import com.clyday.clyday_api.entity.Atividade;
import com.clyday.clyday_api.entity.Pet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.clyday.clyday_api.repository.AtividadeRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class RankingService {

    @Autowired
    private AtividadeRepository repository;

    public int calcularStreak(Pet pet) {
        List<Atividade> atividades = repository.findByPetOrderByDataDesc(pet);

        int streak = 0;
        LocalDate hoje = LocalDate.now();

        for (Atividade a : atividades) {
            if (a.getData().equals(hoje.minusDays(streak))) {
                streak++;
            } else break;
        }
        return streak;
    }

    @Cacheable("ranking")
    public List<Object[]> rankingSemanal() {
        LocalDate inicioSemana = LocalDate.now().minusDays(7);
        return repository.rankingSemanal(inicioSemana);
    }
}
