package com.clyday.clyday_api.controller;

import com.clyday.clyday_api.dto.MedicacaoDTO;
import com.clyday.clyday_api.entity.Medicacao;
import com.clyday.clyday_api.service.MedicacaoService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/medicacoes")
public class MedicacaoController {

    @Autowired
    private MedicacaoService service;

    @PostMapping
    public ResponseEntity<Medicacao> salvar(
            @Valid @RequestBody MedicacaoDTO dto
    ) {
        return ResponseEntity.ok(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<Page<Medicacao>> listar(Pageable pageable) {
        return ResponseEntity.ok(service.listar(pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Medicacao> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {

        service.deletar(id);

        return ResponseEntity.noContent().build();
    }
}
