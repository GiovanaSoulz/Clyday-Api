package com.clyday.clyday_api.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalTime;

@Entity
@Table(name = "medicacoes")
public class Medicacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String nome;

    @NotNull
    private LocalTime horario;

    private Boolean obrigatoria;

    @ManyToOne
    @JoinColumn(name = "pet_id")
    @JsonIgnore
    private Pet pet;

    // GETTERS

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public Boolean getObrigatoria() {
        return obrigatoria;
    }

    public Pet getPet() {
        return pet;
    }

    // SETTERS

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public void setObrigatoria(Boolean obrigatoria) {
        this.obrigatoria = obrigatoria;
    }

    public void setPet(Pet pet) {
        this.pet = pet;
    }
}
