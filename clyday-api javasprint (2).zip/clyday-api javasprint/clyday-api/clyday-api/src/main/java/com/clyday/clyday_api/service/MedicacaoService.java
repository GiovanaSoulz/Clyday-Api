package com.clyday.clyday_api.service;


import com.clyday.clyday_api.dto.MedicacaoDTO;
import com.clyday.clyday_api.entity.Medicacao;
import com.clyday.clyday_api.entity.Pet;
import com.clyday.clyday_api.repository.MedicacaoRepository;
import com.clyday.clyday_api.repository.PetRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalTime;

@Service
public class MedicacaoService {

    @Autowired
    private MedicacaoRepository repository;

    @Autowired
    private PetRepository petRepository;

    public Medicacao salvar(MedicacaoDTO dto) {

        Pet pet = petRepository.findById(dto.getPetId())
                .orElseThrow(() ->
                        new RuntimeException("Pet não encontrado"));

        Medicacao medicacao = new Medicacao();

        medicacao.setNome(dto.getNome());

        medicacao.setHorario(
                LocalTime.parse(dto.getHorario())
        );

        medicacao.setObrigatoria(dto.getObrigatoria());

        medicacao.setPet(pet);

        return repository.save(medicacao);
    }

    public Page<Medicacao> listar(Pageable pageable) {
        return repository.findAll(pageable);
    }

    public Medicacao buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Medicação não encontrada"));
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}