package com.clyday.clyday_api.service;

import com.clyday.clyday_api.util.PontuacaoFactory;
import com.clyday.clyday_api.util.PontuacaoStrategy;
import com.clyday.clyday_api.dto.AtividadeDTO;
import com.clyday.clyday_api.entity.Atividade;
import com.clyday.clyday_api.entity.Pet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.clyday.clyday_api.repository.AtividadeRepository;
import com.clyday.clyday_api.repository.PetRepository;

import java.time.LocalDate;

@Service
public class AtividadeService {

    @Autowired
    private AtividadeRepository repository;

    @Autowired
    private PetRepository petRepository;

    public Atividade salvar(AtividadeDTO dto) {
        Pet pet = petRepository.findById(dto.getPetId())
                .orElseThrow();

        Atividade atividade = new Atividade();
        atividade.setTipo(dto.getTipo());
        atividade.setData(LocalDate.now());

        int pontos = calcularPontos(dto.getTipo());
        atividade.setPontos(pontos);

        atividade.setPet(pet);

        PontuacaoStrategy strategy =
                PontuacaoFactory.getStrategy(dto.getTipo());

        atividade.setPontos(strategy.calcularPontos());

        return repository.save(atividade);
    }

    private int calcularPontos(String tipo) {
        return switch (tipo) {
            case "ALIMENTACAO" -> 10;
            case "AGUA" -> 5;
            case "MEDICACAO" -> 15;
            default -> 0;
        };
    }

}
