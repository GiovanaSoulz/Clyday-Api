package com.clyday.clyday_api.controller;


import com.clyday.clyday_api.dto.AtividadeDTO;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.clyday.clyday_api.service.AtividadeService;
@RestController
@RequestMapping("/atividades")
public class AtividadeController {

    @Autowired
    private AtividadeService service;

    @PostMapping
    public ResponseEntity<?> criar(@Valid @RequestBody AtividadeDTO dto) {
        return ResponseEntity.ok(service.salvar(dto));
    }
}