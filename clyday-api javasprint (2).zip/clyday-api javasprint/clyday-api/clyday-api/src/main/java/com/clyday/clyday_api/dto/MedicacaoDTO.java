package com.clyday.clyday_api.dto;



import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class MedicacaoDTO {

    @NotBlank
    private String nome;

    @NotBlank
    private String horario;

    @NotNull
    private Boolean obrigatoria;

    @NotNull
    private Long petId;

    // GETTERS

    public String getNome() {
        return nome;
    }

    public String getHorario() {
        return horario;
    }

    public Boolean getObrigatoria() {
        return obrigatoria;
    }

    public Long getPetId() {
        return petId;
    }

    // SETTERS

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public void setObrigatoria(Boolean obrigatoria) {
        this.obrigatoria = obrigatoria;
    }

    public void setPetId(Long petId) {
        this.petId = petId;
    }
}
