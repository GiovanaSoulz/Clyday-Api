package com.clyday.clyday_api.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class Atividade {
    
    
    @Id
    @GeneratedValue
    private Long id;
    
    private String tipo;
   private LocalDate data;
    private Integer pontos;
    
    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "pet_id")
    private  Pet pet;

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalDate getData() {
        return data;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPet(Pet pet) {

    }
}
