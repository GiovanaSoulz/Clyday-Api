package com.clyday.clyday_api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.clyday.clyday_api.service.RankingService;

import java.util.List;

@RestController
@RequestMapping("/ranking")
public class RankingController {

    @Autowired
    private RankingService service;

    @GetMapping
    public List<?> ranking() {
        return service.rankingSemanal();
    }
}
