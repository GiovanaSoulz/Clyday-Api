package com.clyday.clyday_api.repository;



import com.clyday.clyday_api.entity.Medicacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MedicacaoRepository extends JpaRepository<Medicacao, Long> {
}
