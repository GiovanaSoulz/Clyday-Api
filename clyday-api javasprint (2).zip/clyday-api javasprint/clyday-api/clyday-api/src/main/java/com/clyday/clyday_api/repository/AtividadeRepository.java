package com.clyday.clyday_api.repository;

import com.clyday.clyday_api.entity.Atividade;
import com.clyday.clyday_api.entity.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AtividadeRepository extends JpaRepository<Atividade, Long> {

    List<Atividade> findByPetOrderByDataDesc(Pet pet);

    @Query("""
    SELECT a.pet.tutor.nome, SUM(a.pontos)
    FROM Atividade a
    WHERE a.data >= :inicioSemana
    GROUP BY a.pet.nome
    ORDER BY SUM(a.pontos) DESC
    """)
    List<Object[]> rankingSemanal(LocalDate inicioSemana);
}