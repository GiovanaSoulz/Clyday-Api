package com.clyday.clyday_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class ClydayApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClydayApiApplication.class, args);
	}

}
